#!/bin/bash
FECHA=$(date +%Y%m%d)
tar -czf $2/backup_$FECHA.tar.gz $1
echo "Backup realizado"

history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
apt update
vim /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
apt update
apt upgrade
cat /etc/apt/sources.list
cat /etc/apt/debian_version
cat /etc/debian_version
reboot
vi /etc/ssh/sshd_config
cat /etc/ssh/sshd_config
apt install openssh-server -y
mkdir -p /root/.ssh
chmod 700 /root/.ssh
ls /root
ls /root/Material_Adicional_TPVMCA
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys 
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
reboot
